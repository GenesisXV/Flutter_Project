package com.example.bitcoin_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
