package com.example.bmipnetexpert

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
